<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8" />
    <title>Motocykle</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
<header>Motocykle - moja pasja</header>



    <?php
    ?>
</body>
</html>